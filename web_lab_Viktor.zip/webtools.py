"""Functii reutilizabile pentru laboratorul de analiza web."""

import csv
import json
import socket
import ssl
import time
from datetime import datetime, timezone
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

TIMEOUT = 10
DEFAULT_HEADERS = {"User-Agent": "WebLab-Viktor"}
OUTPUT_DIR = Path(__file__).resolve().parent
SECURITY_HEADERS = (
    "Strict-Transport-Security", "Content-Security-Policy",
    "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy",
)


def fetch(url):
    """Descarca pagina cu timeout si antetele implicite."""
    return requests.get(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)


def get_status(url):
    """Returneaza codul HTTP al paginii."""
    return fetch(url).status_code


class PageParser(HTMLParser):
    """Extrage titlul si legaturile, indiferent de majuscule sau ghilimele."""

    def __init__(self):
        """Initializeaza rezultatele parserului."""
        super().__init__(convert_charrefs=True)
        self.in_title = False
        self.title = []
        self.links = []

    def handle_starttag(self, tag, attrs):
        """Inregistreaza titlul si atributele href din HTML."""
        if tag == "title":
            self.in_title = True
        href = dict(attrs).get("href")
        if href is not None:
            self.links.append(href)

    def handle_endtag(self, tag):
        """Marcheaza sfarsitul titlului."""
        if tag == "title":
            self.in_title = False

    def handle_data(self, data):
        """Colecteaza textul titlului."""
        if self.in_title:
            self.title.append(data)


def get_title(html):
    """Extrage titlul si decodeaza entitatile HTML."""
    parser = PageParser()
    parser.feed(html)
    return "".join(parser.title).strip()


def security_headers(url):
    """Verifica prezenta celor cinci antete de securitate."""
    response = fetch(url)
    return {name: name in response.headers for name in SECURITY_HEADERS}


def score_headers(results):
    """Returneaza scorul antetelor in forma existente/total."""
    return f"{sum(results.values())}/{len(results)}"


def resolve(hostname):
    """Returneaza adresa IPv4 a domeniului."""
    return socket.gethostbyname(hostname)


def cert_days_left(hostname, port=443):
    """Returneaza zilele ramase pana la expirarea certificatului TLS."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, port), timeout=TIMEOUT) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            certificate = ssock.getpeercert()
    expiry = datetime.fromtimestamp(
        ssl.cert_time_to_seconds(certificate["notAfter"]), timezone.utc
    )
    return (expiry - datetime.now(timezone.utc)).days


def extract_links(html):
    """Extrage valorile href fara duplicate."""
    parser = PageParser()
    parser.feed(html)
    return list(dict.fromkeys(parser.links))


def split_links(links, domain):
    """Separa URL-urile HTTP interne/externe fata de URL-ul paginii."""
    base = domain if "://" in domain else "https://" + domain + "/"
    hostname = urlparse(base).hostname
    internal, external = [], []
    seen = set()
    for link in links:
        absolute = urljoin(base, link.strip())
        parsed = urlparse(absolute)
        if parsed.scheme not in ("http", "https") or absolute in seen:
            continue
        seen.add(absolute)
        (internal if parsed.hostname == hostname else external).append(absolute)
    return internal, external


def fetch_robots(base):
    """Descarca robots.txt de la radacina sau returneaza None."""
    try:
        response = fetch(urljoin(base, "/robots.txt"))
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(robots_text):
    """Extrage directivele Disallow necomplet goale, fara comentarii."""
    paths = []
    for line in (robots_text or "").splitlines():
        name, separator, value = line.split("#", 1)[0].partition(":")
        if separator and name.strip().lower() == "disallow" and value.strip():
            paths.append(value.strip())
    return list(dict.fromkeys(paths))


def check_paths(base, paths):
    """Verifica paginile cu o pauza de o secunda intre cereri."""
    results = {}
    for index, path in enumerate(paths):
        if index:
            time.sleep(1)
        results[path] = get_status(urljoin(base, path))
    return results


def save_csv(base):
    """Salveaza raportul exercitiului 49 cu cele trei coloane cerute."""
    results = check_paths(base, ["/", "/robots.txt", "/sitemap.xml"])
    with (OUTPUT_DIR / "report.csv").open("w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in results.items():
            writer.writerow([path, status, datetime.now().isoformat()])


def site_report(url):
    """Colecteaza, afiseaza si salveaza toate datele exercitiului 50."""
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("Introduceti un URL complet, de exemplu https://cybercor.org")
    response = fetch(url)
    final = urlparse(response.url)
    hostname = final.hostname
    errors = {}

    def optional(name, operation):
        """Pastreaza raportul disponibil daca o verificare esueaza."""
        try:
            return operation()
        except (requests.RequestException, OSError, ValueError) as error:
            errors[name] = str(error)
            return None

    ip = optional("dns", lambda: resolve(hostname))
    time.sleep(1)
    redirect_response = optional("redirectionari", lambda: fetch("http://" + parsed.netloc))
    redirects = None if redirect_response is None else [
        {"status": item.status_code, "url": item.url,
         "destinatie": urljoin(item.url, item.headers.get("Location", ""))}
        for item in redirect_response.history
    ]
    # Refolosim raspunsul initial pentru antete: nu este necesara alta cerere.
    headers = {name: name in response.headers for name in SECURITY_HEADERS}
    days = optional("certificat", lambda: cert_days_left(
        hostname, (final.port or 443) if final.scheme == "https" else 443
    ))
    internal, external = split_links(extract_links(response.text), response.url)
    time.sleep(1)
    robots = fetch_robots(response.url)
    if robots is None:
        errors["robots"] = "robots.txt indisponibil; caile nu au putut fi verificate."
    report = {
        "url": response.url, "status": response.status_code,
        "titlu": get_title(response.text), "ip": ip,
        "redirectionari": redirects,
        "scor_securitate": score_headers(headers),
        "certificat_zile": days,
        "linkuri_interne": len(internal), "linkuri_externe": len(external),
        "cai_interzise": disallowed_paths(robots),
    }
    if errors:
        report["erori"] = errors
    print(f"=== Raport site: {url} ===")
    for label, key in [("Cod de stare", "status"), ("URL final", "url"),
                       ("Titlu", "titlu"), ("Adresa IP", "ip")]:
        print(f"{label}: {report[key]}")
    if redirect_response is None:
        print("Redirectionari: verificare indisponibila")
    else:
        chain = [f"{item['status']} -> {item['destinatie']}" for item in redirects]
        print("Redirectionari:", " | ".join(chain) or "Niciuna")
        print("URL final din HTTP:", redirect_response.url)
        report["url_final_http"] = redirect_response.url
    print("Scor securitate:", report["scor_securitate"])
    print("Certificat:", f"{days} zile ramase" if days is not None else "indisponibil")
    print(f"Legaturi: {len(internal)} interne, {len(external)} externe")
    print("Cai interzise:", ", ".join(report["cai_interzise"]) or "Niciuna")
    for name, message in errors.items():
        print(f"Verificare indisponibila ({name}): {message}")
    output = OUTPUT_DIR / "report.json"
    with output.open("w", encoding="utf-8") as file:
        json.dump(report, file, indent=2, ensure_ascii=False)
    print("Salvat in", output)
    return report


if __name__ == "__main__":
    print("Autotest:", get_status("https://cybercor.org"))
