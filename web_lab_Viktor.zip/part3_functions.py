
import requests

# Exercitiul 21

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def fetch(url):
    """Returneaza raspunsul primit de la un site web."""
    response = requests.get(url, timeout=TIMEOUT)
    return response

rezultat = fetch(BASE_URL)

print("Status code:", rezultat.status_code)



import requests
import time

# Exercitiul 22

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def get_status(url):
    """Returneaza codul de stare HTTP al paginii."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print("Pagina principala:", get_status(BASE_URL + "/"))

time.sleep(1)

print("Robots.txt:", get_status(BASE_URL + "/robots.txt"))

time.sleep(1)

print("Sitemap.xml:", get_status(BASE_URL + "/sitemap.xml"))



import requests
import time

# Exercitiul 23

BASE_URL = "https://cybercor.org"

def fetch(url, timeout=10):
    """Returneaza raspunsul unui site web."""
    response = requests.get(url, timeout=timeout)
    return response

rezultat1 = fetch(BASE_URL)
print("Status code 1:", rezultat1.status_code)

time.sleep(1)
rezultat2 = fetch(BASE_URL, timeout=3)
print("Status code 2:", rezultat2.status_code)


import requests

# Exercitiul 24

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def get_title(html):
    """Extrage si returneaza titlul unei pagini HTML."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")

    titlu = html[start:end].strip()

    return titlu

response = requests.get(BASE_URL, timeout=TIMEOUT)

rezultat = get_title(response.text)

print("Titlul paginii:", rezultat)



import requests

# Exercitiul 25

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def get_title(html):
    """Extrage titlul unei pagini HTML si il returneaza."""
    start = html.find("<title>") + len("<title>")
    end = html.find("</title>")

    titlu = html[start:end].strip()
    return titlu

response = requests.get(BASE_URL, timeout=TIMEOUT)

print("Titlul paginii:", get_title(response.text))

help(get_title)



import requests

# Exercitiul 26

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def get_status(url: str) -> int:
    """Returneaza codul de stare HTTP al unei pagini."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

print("Status:", get_status(BASE_URL))

try:
    print(get_status(123))
except requests.RequestException as e:
    print("Eroare:", e)


import requests
import time

# Exercitiul 27

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def page_exists(url):
    """Verifica daca o pagina exista si returneaza True sau False."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        response.raise_for_status()
        return True

    except requests.RequestException:
        return False

print("Pagina principala:", page_exists(BASE_URL))

time.sleep(1)

print("Pagina inexistenta:", page_exists("https://this-domain-does-not-exist.invalid"))




import requests
import time

# Exercitiul 28

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def check_paths(base, paths):
    """Verifica paginile si returneaza codurile HTTP intr-un dictionar."""

    rezultate = {}

    for path in paths:
        response = requests.get(base + path, timeout=TIMEOUT)
        rezultate[path] = response.status_code
        time.sleep(1)

    return rezultate

paths = ["/", "/robots.txt", "/sitemap.xml"]

rezultat = check_paths(BASE_URL, paths)

print(rezultat)



import requests

# Exercitiul 29

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def get_header(url, name, default="lipsește"):
    """Returneaza valoarea unui antet HTTP."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.headers.get(name, default)

rezultat = get_header(BASE_URL, name="Server")

print("Server:", rezultat)


import requests

# Exercitiul 30

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def security_headers(url):
    """Verifica prezenta antetelor de securitate ale unui site."""

    response = requests.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    rezultate = {}

    for header in headers:
        rezultate[header] = header in response.headers

    return rezultate

rezultat = security_headers(BASE_URL)

for nume, valoare in rezultat.items():
    print(nume, ":", valoare)


import requests

# Exercitiul 31

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def security_headers(url):
    """Verifica prezenta antetelor de securitate."""

    response = requests.get(url, timeout=TIMEOUT)

    headers = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]

    rezultate = {}

    for header in headers:
        rezultate[header] = header in response.headers

    return rezultate


def score_headers(results):
    """Calculeaza scorul antetelor de securitate."""

    existente = sum(results.values())
    total = len(results)

    return f"{existente}/{total}"


print("Scor securitate:", score_headers(security_headers(BASE_URL)))



import requests

# Exercitiul 32

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def fetch_robots(base):
    """Descarca fisierul robots.txt sau returneaza None."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        response.raise_for_status()
        return response.text
    except requests.RequestException:
        return None


def disallowed_paths(robots_text):
    """Returneaza toate valorile Disallow din robots.txt."""
    paths = []

    if robots_text is None:
        return paths

    for line in robots_text.splitlines():
        if line.strip().startswith("Disallow:"):
            path = line.split(":", 1)[1].strip()
            paths.append(path)

    return paths


robots = fetch_robots(BASE_URL)
rezultat = disallowed_paths(robots)

print("Cai interzise:", rezultat)



import requests
import time

# Exercitiul 33

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def response_times(*urls):
    """Returneaza timpul de raspuns pentru fiecare URL."""

    rezultate = {}

    for i, url in enumerate(urls):
        start = time.perf_counter()

        response = requests.get(url, timeout=TIMEOUT)

        end = time.perf_counter()

        rezultate[url] = end - start

        if i < len(urls) - 1:
            time.sleep(1)

    return rezultate


rezultat = response_times(
    BASE_URL,
    BASE_URL + "/robots.txt"
)

print(rezultat)



# Exercitiul 34

BASE_URL = "https://cybercor.org"

def log(message, **details):
    """Afiseaza un mesaj si detaliile primite."""

    print(message, end="")

    for nume, valoare in details.items():
        print(" |", nume + "=" + str(valoare), end="")

    print()


log("verificat", url=BASE_URL, status=200)
