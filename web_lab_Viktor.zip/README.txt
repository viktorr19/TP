Rulare din directorul web_lab:
    python main.py https://cybercor.org

Rulare din directorul parinte:
    python -m web_lab.main https://cybercor.org

Dependenta (daca nu este instalata):
    python -m pip install -r requirements.txt

Raportul complet se afiseaza in terminal si se salveaza in report.json,
intotdeauna in directorul web_lab, indiferent de directorul de pornire.
Erorile verificarilor DNS/TLS/redirectari sunt incluse in campul erori.
Lipsa robots.txt este semnalata; lista goala nu confirma absenta restrictiilor.

Exercitiul 49, generare separata report.csv din web_lab:
    python -c "import webtools; webtools.save_csv('https://cybercor.org')"

Autotestul modulului (exercitiul 46):
    python webtools.py
