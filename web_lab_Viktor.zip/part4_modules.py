    
# Exercitiul 35

from urllib.parse import urlparse

def descompune_url(url):
    """Descompune un URL in componentele sale."""

    rezultat = urlparse(url)

    print("Scheme:", rezultat.scheme)
    print("Netloc:", rezultat.netloc)
    print("Path:", rezultat.path)
    print("Query:", rezultat.query)
    print("Fragment:", rezultat.fragment)


url = "https://cybercor.org/path?x=1#top"

descompune_url(url)


# Exercitiul 36

from urllib.parse import urljoin

BASE_URL = "https://cybercor.org"

def compune_url(base, links):
    """Transforma linkurile relative in URL-uri complete."""

    for link in links:
        rezultat = urljoin(base, link)
        print(rezultat)


links = ["/about", "contact.html", "../index.html"]

compune_url(BASE_URL, links)


import requests
import re

# Exercitiul 37

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def extract_links(html):
    """Extrage linkurile din HTML si elimina duplicatele."""

    links = re.findall(r'href="([^"]+)"', html)

    links = list(dict.fromkeys(links))

    return links


response = requests.get(BASE_URL, timeout=TIMEOUT)

rezultat = extract_links(response.text)

for link in rezultat:
    print(link)



import requests
import re
from urllib.parse import urljoin, urlparse

# Exercitiul 38

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def extract_links(html):
    """Extrage linkurile din HTML fara duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    return list(dict.fromkeys(links))


def split_links(links, domain):
    """Separa linkurile interne de cele externe."""

    interne = []
    externe = []

    for link in links:
        url_complet = urljoin("https://" + domain, link)
        domeniu_link = urlparse(url_complet).netloc

        if domeniu_link == domain:
            interne.append(url_complet)
        else:
            externe.append(url_complet)

    return interne, externe


response = requests.get(BASE_URL, timeout=TIMEOUT)

links = extract_links(response.text)

interne, externe = split_links(links, "cybercor.org")

print("Linkuri interne:", interne)
print("Linkuri externe:", externe)



import requests
from html.parser import HTMLParser

# Exercitiul 39

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

class ImageFinder(HTMLParser):
    """Gaseste imaginile din codul HTML."""

    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        if tag == "img":
            src = dict(attrs).get("src")

            if src:
                self.images.append(src)


def test_images():
    """Testeaza clasa ImageFinder."""

    test_html = """
    <html><body>
        <img src="/logo.png" alt="Logo">
        <IMG SRC="poza.jpg">
        <img alt="imagine fara src">
        <img src="https://cdn.example.com/banner.webp" />
        <a href="/despre">Aceasta nu este o imagine</a>
    </body></html>
    """

    finder = ImageFinder()
    finder.feed(test_html)

    print(finder.images)

    assert finder.images == [
        "/logo.png",
        "poza.jpg",
        "https://cdn.example.com/banner.webp"
    ], "Parserul nu a gasit imaginile asteptate"

    print("Testul a trecut!")


def find_site_images(url):
    """Gaseste imaginile de pe un site web."""

    response = requests.get(url, timeout=TIMEOUT)

    finder = ImageFinder()
    finder.feed(response.text)

    print(len(finder.images), "imagini gasite")

    for src in finder.images:
        print(src)

    print("Taguri img in HTML:",
          response.text.lower().count("<img"))


test_images()
find_site_images(BASE_URL)



import requests
import hashlib
import time

# Exercitiul 40

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def page_fingerprint(url):
    """Calculeaza amprenta SHA-256 a unei pagini web."""

    response = requests.get(url, timeout=TIMEOUT)

    hash_pagina = hashlib.sha256(response.content).hexdigest()

    return hash_pagina


hash1 = page_fingerprint(BASE_URL)

time.sleep(1)

hash2 = page_fingerprint(BASE_URL)

print("Primul hash:", hash1)
print("Al doilea hash:", hash2)

if hash1 == hash2:
    print("Paginile au acelasi continut.")
else:
    print("Continutul paginii s-a modificat.")



import requests
import json

# Exercitiul 41

BASE_URL = "https://cybercor.org"
TIMEOUT = 10

def save_headers(url):
    """Salveaza antetele HTTP in JSON si le citeste."""

    response = requests.get(url, timeout=TIMEOUT)

    with open("headers.json", "w") as file:
        json.dump(dict(response.headers), file, indent=2)

    with open("headers.json", "r") as file:
        headers = json.load(file)

    print("Content-Type:", headers.get("Content-Type", "lipseste"))


save_headers(BASE_URL)



import socket

# Exercitiul 42

def resolve(hostname):
    """Returneaza adresa IP a unui domeniu."""
    ip = socket.gethostbyname(hostname)
    return ip

hostname = "cybercor.org"

rezultat = resolve(hostname)

print("Adresa IP:", rezultat)



import ssl
import socket
from datetime import datetime, timezone

# Exercitiul 43

def cert_days_left(hostname):
    """Returneaza numarul de zile pana la expirarea certificatului."""

    context = ssl.create_default_context()

    with socket.create_connection((hostname, 443), timeout=10) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            certificat = ssock.getpeercert()

    data_expirare = certificat["notAfter"]

    timestamp = ssl.cert_time_to_seconds(data_expirare)

    expirare = datetime.fromtimestamp(timestamp, timezone.utc)
    acum = datetime.now(timezone.utc)

    zile_ramase = (expirare - acum).days

    return zile_ramase


hostname = "cybercor.org"

rezultat = cert_days_left(hostname)

print("Zile ramase pana la expirare:", rezultat)

