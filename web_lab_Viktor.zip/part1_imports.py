# Exercitiul 1: Primul import

import requests
import urllib.request

print("Versiunea requests:", requests.__version__)

# requests este o biblioteca externa si necesita pip install.
# urllib.request face parte din biblioteca standard Python.


# Exercitiul 2: Primul stil de import

BASE_URL = "https://cybercor.org"

response = requests.get(BASE_URL)
print("Stilul 1 - Cod de stare:", response.status_code)

# Avantaj: numele requests arata clar de unde vine functia.


# Exercitiul 2: Al doilea stil de import

from requests import get

response = get(BASE_URL)
print("Stilul 2 - Cod de stare:", response.status_code)

# Avantaj: cod mai scurt, deoarece apelam direct get().

#Exercitiul 3: Al treilea stil de import (ALIAS)
import requests as rq

BASE_URL = "https://cybercor.org"
response = rq.get(BASE_URL)
print("Stilul 3 - Cod de stare:", response.status_code)

# Un alias face codul mai usor de citit cand scurteaza
# numele lung folosit frecvent. Poate face codul mai greu
# de inteles daca alias-ul este neclar sau necunoscut.


# Exercitiul 4: Doar biblioteca standard

import urllib.request

BASE_URL = "https://cybercor.org"

request = urllib.request.Request(BASE_URL, headers={"User-Agent": "Mozilla/5.0"})

response = urllib.request.urlopen(request)

print("Cod de stare:", response.status)

body = response.read().decode("utf-8")
print("Primele 200 de caractere:")
print(body[:200])

response.close()

#Exercitiul 5: Inspectarea bibliotecii requests
print(dir(requests))

# get - functie: trimite o cerere HTTP de tip GET
# Session - clasa: permite gestionarea unei sesiuni HTTP
# exceptions - modul: contine exceptiile folosite de requests

#Exercitiul 6: Inspectarea functiei get()
help (requests.get)

BASE_URL = "https://cybercor.org"
response = requests.get(BASE_URL, timeout=5)
print("Cod de stare:", response.status_code)

# Exercitiul 7: Inspectarea raspunsului
import time 
BASE_URL = "https://cybercor.org"
start_time = time.perf_counter()
response = requests.get(BASE_URL, timeout = 10)
end_time = time.perf_counter()
duration = end_time - start_time
print("Cod de stare:", response.status_code)
print("Durata cererii:", duration, "secunde")
print("Timp de raspuns:", response.elapsed.total_seconds(), "secunde")

#Exeritiul 8 : Inspectarea bibliotecii BeautifulSoup4

try:
    import bs4
    print("Biblioteca BeautifulSoup4 este instalata.")

except ImportError:
    print("Biblioteca BeautifulSoup4 nu este instalata. Instalati-o folosind pip install beautifulsoup4.")  


