"""Programul de pornire pentru raportul site-ului (exercitiul 50)."""

import argparse
import sys

import requests

if __package__:
    from . import webtools
else:
    import webtools

# O functie locala numita get_title ar suprascrie numele importat prin
# 'from webtools import get_title'. Importul modulului evita aceasta coliziune.
# Autotestul webtools ruleaza doar cand acel fisier este executat direct,
# deoarece la import __name__ este numele modulului, nu '__main__'.


def main(argv=None):
    """Citeste URL-ul din terminal si genereaza raportul complet."""
    parser = argparse.ArgumentParser(description="Genereaza raportul unui site web.")
    parser.add_argument("url", help="Adresa HTTP sau HTTPS a site-ului")
    args = parser.parse_args(argv)
    print("Antetele implicite:", webtools.DEFAULT_HEADERS)
    try:
        webtools.site_report(args.url)
    except (requests.RequestException, ValueError, OSError) as error:
        print(f"Eroare: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
