# Exercitiul 9

import requests

BASE_URL = "https://cybercor.org"
timeout = 10

response = requests.get(BASE_URL, timeout=timeout)
print("Status code:", response.status_code)  # Atribut
print("ok:", response.ok)  # Atribut
print("URL:", response.url)  # Atribut
print("Encoding:", response.encoding)  # Atribut


# Exercitiul 10

import requests

BASE_URL = "https://cybercor.org"
timeout = 10

try:
    response = requests.get(BASE_URL + "/this-page-does-not-exist", timeout=timeout)
    response.raise_for_status()  # Metoda
    print("Status code:", response.status_code)

except requests.HTTPError:
    print("Error:")

# Exercitiul 11

BASE_URL = "https://cybercor.org"
timeout = 10

response = requests.get(BASE_URL, timeout=timeout)

for numer, valoare in response.headers.items():
    print(numer, ":", valoare)

    # Exercitiul 12

    BASE_URL = "https://cybercor.org"
    timeout = 10
    response = requests.get(BASE_URL, timeout=timeout)
print("Content-Type:", response.headers.get("Content-Type", "lipseste"))
print("Server:", response.headers.get("Server", "lipseste"))
print("content-type:", response.headers.get("content-type", "lipseste"))

# Exercitiul 13

BASE_URL = "https://cybercor.org"
timeout = 10
response = requests.get(BASE_URL, timeout=timeout)
print("Number of cyber:", response.text.lower().count("cyber"))
# Putem inlantui metodele deoarece lower() returneaza un sir de caractere
# pe care putem aplica imediat metoda count()


# Exercitiul 14

BASE_URL = "https://cybercor.org"
timeout = 10
response = requests.get(BASE_URL, timeout=timeout)

html = response.text

start = html.find("<title>") + len("<title>")
end = html.find("</title>")

titlu = html[start:end].strip()

print("Titlul paginii:", titlu)

# Exercitiul 15

BASE_URL = "https://cybercor.org"
timeout = 10
response = requests.get(BASE_URL, timeout=timeout)

html = response.text

lines = html.splitlines()
print("Numarul de linii:", len(lines))

longest_line = max(lines, key=len)
print ("Cea mai lunga linie are", len(longest_line), "caractere.")
shortest_line = min(lines, key=len)
print ("Cea mai scurta linie are", len(shortest_line), "caractere.")

#Exercitiul 16

BASE_URL = "https://cybercor.org"
response = requests.get(BASE_URL, timeout= timeout)
timeout = 10

BASE_URL.startswith("https://")
print(BASE_URL.startswith("https://"))


#Exercitiul 17

BASE_URL = "http://cybercor.org"
timeout = 10
response = requests.get(BASE_URL, timeout=timeout)

for redirect in response.history:
    print("Status Code", redirect.status_code)
    print ("URL", redirect.url)
    print ("URL Final" , response.url)

#Exercitiul 18
import time
BASE_URL = "https://cybercor.org"
timeout = 10
response_head = requests.head(BASE_URL, timeout=timeout)
response = requests.get(BASE_URL, timeout=timeout)
time.sleep(1)
print("HEAD" , len(response_head.content))
print("GET", len(response.content))

#Exercitiul 19

BASE_URL  = "https://cybercor.org"
timeout = 10
response = requests.get(BASE_URL, timeout=timeout)

if response.cookies:
    for cookie in response.cookies:
        print("Nume:", cookie.name)
        print("Secure:", cookie.secure)
else:
    print("Niciun cookie setat")

    #Ecercitiul 20

   


# Exercitiul 20

ECHO_URL = "https://httpbin.org"
timeout = 10

session = requests.Session()

session.headers.update({"User-Agent": "WebLab-Viktor"})

response = session.get(ECHO_URL + "/headers", timeout=timeout)

print(response.json())


